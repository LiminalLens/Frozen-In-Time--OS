FROZEN IN TIME — VM DESTINATION
================================

This folder is intentionally empty in Prototype 2.

The intended final architecture is:

Frozen in Time bootable USB
    -> Frozen in Time launcher
    -> selected timeline configuration
    -> isolated virtual machine
    -> user-provided/licensed period Windows installation
    -> TimeNet network layer
    -> archived + curated historical content
    -> AI contacts

Prototype 2 DOES NOT include Microsoft Windows, a Windows product key,
a Windows ISO, or an installed Windows virtual disk.

Do not copy an important Windows installation into this folder yet.
We will wire the VM layer deliberately in a later prototype.

# Contributing

Frozen in Time OS is currently an early prototype.

Areas that will eventually need work include:

- bootable Linux host environment
- VM orchestration
- historical web routing
- UI/UX
- TimeNet server infrastructure
- historical datasets
- AI persona systems
- archive/download safety
- compatibility testing

Please avoid adding proprietary Windows images, commercial software, copyrighted media archives, or credentials to the repository.

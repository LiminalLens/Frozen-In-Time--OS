@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\FrozenInTime.ps1"
if errorlevel 1 (
  echo.
  echo Frozen in Time could not start.
  echo If Windows blocked PowerShell, right-click this file and choose Run as administrator only if you trust these prototype files.
  pause
)

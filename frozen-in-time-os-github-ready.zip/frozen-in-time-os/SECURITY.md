# Security Notes

Frozen in Time OS is intended to isolate period software and historical downloads from the user's modern host operating system.

Future development should preserve these rules:

1. Do not automatically execute archived binaries on the host OS.
2. Run period executables only inside isolated virtual machines or equivalent sandboxes.
3. Keep the host operating system outside the simulated timeline.
4. Treat downloaded historical files as untrusted.
5. Never disable host security features merely for authenticity.

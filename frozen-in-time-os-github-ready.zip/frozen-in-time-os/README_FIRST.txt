FROZEN IN TIME — PROTOTYPE 2
=============================

This is the improved second prototype.

WHAT CHANGED FROM PROTOTYPE 1
-----------------------------
- This is NOT a website.
- The launcher is a native Windows WPF interface powered by PowerShell.
- There is no fake HTML Windows desktop.
- The launcher focuses on the real future architecture:
  timeline -> Windows VM -> TimeNet -> AI contacts.
- It creates a real timeline session configuration file for later VM integration.
- The project folders now match the system we can grow into.

HOW TO RUN IT
-------------
1. Extract this entire folder onto the USB.
2. Open the USB.
3. Double-click START_FROZEN_IN_TIME.cmd
4. Choose the year, date, time, OS destination, and friend pack.
5. Click PREPARE TIMELINE.

WHAT HAPPENS
------------
Prototype 2 saves your selection into:

config\last-session.json

That file is the beginning of the control interface we'll eventually pass to:
- the Windows virtual machine
- TimeNet
- the AI contact service

WHAT IT DOES NOT DO YET
-----------------------
- It is not a bootable ISO yet.
- It does not launch Windows 7 yet.
- It does not include Microsoft Windows.
- It does not access the Wayback Machine yet.
- It does not connect to an AI service yet.

WHY
---
Those features need to be added in the right order. This prototype establishes the
native launcher and data model first, so the later bootable ISO and VM do not have
to be built around a throwaway website prototype.

RUFUS
-----
Do not write this ZIP with Rufus. Prototype 2 still launches from an existing
Windows computer. Rufus becomes relevant once we produce an actual bootable ISO.

SAFETY
------
This package does not modify Windows system files and does not install an OS.

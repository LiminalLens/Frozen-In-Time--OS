
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$Base = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$ConfigPath = Join-Path $Base "config\eras.json"
$FriendsPath = Join-Path $Base "friends\personas.json"
$StatePath = Join-Path $Base "config\last-session.json"
$LogPath = Join-Path $Base "logs\frozen.log"

function Write-Log([string]$Message) {
    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -LiteralPath $LogPath -Value "[$stamp] $Message"
}

$config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
$friendData = Get-Content -LiteralPath $FriendsPath -Raw | ConvertFrom-Json

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Frozen in Time"
        WindowStartupLocation="CenterScreen"
        Width="1100" Height="760"
        MinWidth="940" MinHeight="680"
        Background="#05080D"
        Foreground="#EAF6FF"
        FontFamily="Segoe UI">
    <Window.Resources>
        <Style TargetType="Button">
            <Setter Property="Background" Value="#101923"/>
            <Setter Property="Foreground" Value="#EAF6FF"/>
            <Setter Property="BorderBrush" Value="#2C78A8"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Padding" Value="12,8"/>
            <Setter Property="Margin" Value="4"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="ComboBox">
            <Setter Property="Margin" Value="4"/>
            <Setter Property="Padding" Value="8"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="TextBox">
            <Setter Property="Margin" Value="4"/>
            <Setter Property="Padding" Value="8"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="DatePicker">
            <Setter Property="Margin" Value="4"/>
            <Setter Property="Padding" Value="5"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
    </Window.Resources>

    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="145"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="105"/>
        </Grid.RowDefinitions>

        <!-- Header -->
        <Border Grid.Row="0" Background="#080F17" BorderBrush="#1C587E" BorderThickness="0,0,0,1">
            <Grid Margin="32,22">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="330"/>
                </Grid.ColumnDefinitions>
                <StackPanel>
                    <TextBlock Text="FROZEN IN TIME" FontSize="42" FontWeight="SemiBold" Foreground="#F4FBFF"/>
                    <TextBlock Text="Pick a year. Enter a living digital past." FontSize="18" Foreground="#6FC7F2" Margin="2,5,0,0"/>
                    <TextBlock Text="Prototype 2 • Native launcher • VM + TimeNet control plane" FontSize="12" Foreground="#71889A" Margin="2,9,0,0"/>
                </StackPanel>
                <Border Grid.Column="1" BorderBrush="#184B6A" BorderThickness="1" CornerRadius="5" Padding="16" Background="#08131D">
                    <StackPanel>
                        <TextBlock Text="CORE RULE" Foreground="#65CAFF" FontWeight="Bold" FontSize="12"/>
                        <TextBlock Text="Frozen in Time controls the timeline around Windows. It does not replace your host Windows installation." 
                                   TextWrapping="Wrap" FontSize="13" Margin="0,6,0,0" Foreground="#B9D0DF"/>
                    </StackPanel>
                </Border>
            </Grid>
        </Border>

        <!-- Main content -->
        <Grid Grid.Row="1" Margin="30,24">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="1.05*"/>
                <ColumnDefinition Width="0.95*"/>
            </Grid.ColumnDefinitions>

            <StackPanel Grid.Column="0" Margin="0,0,22,0">
                <TextBlock Text="DESTINATION" FontSize="13" FontWeight="Bold" Foreground="#65CAFF" Margin="4,0,0,6"/>
                <Border Background="#09131D" BorderBrush="#173E59" BorderThickness="1" CornerRadius="6" Padding="16">
                    <StackPanel>
                        <TextBlock Text="Year" Foreground="#9AB3C4"/>
                        <ComboBox Name="YearBox"/>
                        <TextBlock Text="Date" Foreground="#9AB3C4" Margin="0,10,0,0"/>
                        <DatePicker Name="DateBox"/>
                        <TextBlock Text="Time" Foreground="#9AB3C4" Margin="0,10,0,0"/>
                        <TextBox Name="TimeBox" Text="22:24"/>
                        <TextBlock Text="Operating-system destination" Foreground="#9AB3C4" Margin="0,10,0,0"/>
                        <ComboBox Name="OSBox"/>
                        <TextBlock Text="Friend pack" Foreground="#9AB3C4" Margin="0,10,0,0"/>
                        <ComboBox Name="FriendBox"/>
                    </StackPanel>
                </Border>

                <TextBlock Text="TIMELINE NETWORK" FontSize="13" FontWeight="Bold" Foreground="#65CAFF" Margin="4,18,0,6"/>
                <Border Background="#09131D" BorderBrush="#173E59" BorderThickness="1" CornerRadius="6" Padding="16">
                    <StackPanel>
                        <TextBlock Text="TimeNet" FontSize="18" FontWeight="SemiBold"/>
                        <TextBlock Text="In the finished system, the selected virtual machine will use a Frozen in Time network layer for era-matched pages, search, news, downloads and AI contacts." 
                                   TextWrapping="Wrap" Foreground="#A9BECC" Margin="0,6,0,0"/>
                        <CheckBox Name="ArchiveCheck" Content="Use archived web content when available" IsChecked="True" Margin="0,12,0,0" Foreground="#DCEAF2"/>
                        <CheckBox Name="CuratedCheck" Content="Fall back to curated TimeNet content" IsChecked="True" Margin="0,6,0,0" Foreground="#DCEAF2"/>
                        <CheckBox Name="AIcheck" Content="Enable AI contacts" IsChecked="True" Margin="0,6,0,0" Foreground="#DCEAF2"/>
                    </StackPanel>
                </Border>
            </StackPanel>

            <StackPanel Grid.Column="1">
                <TextBlock Text="SESSION PREVIEW" FontSize="13" FontWeight="Bold" Foreground="#65CAFF" Margin="4,0,0,6"/>
                <Border Background="#071019" BorderBrush="#205F86" BorderThickness="1" CornerRadius="6" Padding="20">
                    <StackPanel>
                        <TextBlock Name="DestinationText" Text="AUGUST 15, 2008 • 10:24 PM" FontSize="23" FontWeight="SemiBold" Foreground="#FFFFFF"/>
                        <TextBlock Name="OSText" Text="Windows 7" FontSize="17" Foreground="#7FD1FA" Margin="0,5,0,0"/>
                        <Separator Margin="0,18"/>
                        <TextBlock Text="When the real VM layer is added:" Foreground="#9AB3C4" FontWeight="Bold"/>
                        <TextBlock Text="• Windows runs inside an isolated virtual machine" Margin="0,9,0,0"/>
                        <TextBlock Text="• The host computer's Windows installation stays untouched" Margin="0,5,0,0"/>
                        <TextBlock Text="• TimeNet controls what the VM sees online" Margin="0,5,0,0"/>
                        <TextBlock Text="• AI contacts obey the selected date's knowledge cutoff" Margin="0,5,0,0"/>
                        <TextBlock Text="• Archived downloads go into the VM, not the host" Margin="0,5,0,0"/>
                        <Separator Margin="0,18"/>
                        <TextBlock Text="Friend pack" Foreground="#9AB3C4" FontWeight="Bold"/>
                        <TextBlock Name="FriendText" Text="Classic Friends" FontSize="17" Foreground="#FFFFFF" Margin="0,5,0,0"/>
                        <TextBlock Name="FriendDetails" Text="Kayla • Chris • Tyler • Ashley" Foreground="#89A5B8" Margin="0,3,0,0" TextWrapping="Wrap"/>
                    </StackPanel>
                </Border>

                <TextBlock Text="PROTOTYPE 2 STATUS" FontSize="13" FontWeight="Bold" Foreground="#65CAFF" Margin="4,18,0,6"/>
                <Border Background="#09131D" BorderBrush="#173E59" BorderThickness="1" CornerRadius="6" Padding="16">
                    <Grid>
                        <Grid.ColumnDefinitions>
                            <ColumnDefinition Width="*"/>
                            <ColumnDefinition Width="Auto"/>
                        </Grid.ColumnDefinitions>
                        <StackPanel>
                            <TextBlock Text="Launcher" FontWeight="Bold"/>
                            <TextBlock Text="Native Windows WPF — no browser required" Foreground="#89A5B8"/>
                            <TextBlock Text="Windows VM" FontWeight="Bold" Margin="0,10,0,0"/>
                            <TextBlock Text="Not included yet — placeholder wiring only" Foreground="#89A5B8"/>
                            <TextBlock Text="TimeNet" FontWeight="Bold" Margin="0,10,0,0"/>
                            <TextBlock Text="Architecture stub included" Foreground="#89A5B8"/>
                        </StackPanel>
                        <TextBlock Grid.Column="1" Text="v0.2" FontSize="32" Foreground="#256F9B" VerticalAlignment="Center" Margin="20,0,0,0"/>
                    </Grid>
                </Border>
            </StackPanel>
        </Grid>

        <!-- Footer -->
        <Border Grid.Row="2" Background="#071019" BorderBrush="#1C587E" BorderThickness="0,1,0,0">
            <Grid Margin="30,17">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <StackPanel VerticalAlignment="Center">
                    <TextBlock Text="This button saves the timeline session and prepares the VM launch configuration." Foreground="#A9BECC"/>
                    <TextBlock Text="It will not launch Windows 7 until a VM engine and your own Windows installation media are connected in a later prototype." 
                               Foreground="#6F8798" FontSize="11" Margin="0,4,0,0"/>
                </StackPanel>
                <Button Name="EnterButton" Grid.Column="1" Content="PREPARE TIMELINE" FontSize="18" FontWeight="Bold"
                        Background="#0E70AF" BorderBrush="#6ED5FF" Padding="26,13" Margin="18,0,0,0"/>
            </Grid>
        </Border>
    </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

$YearBox = $window.FindName("YearBox")
$DateBox = $window.FindName("DateBox")
$TimeBox = $window.FindName("TimeBox")
$OSBox = $window.FindName("OSBox")
$FriendBox = $window.FindName("FriendBox")
$DestinationText = $window.FindName("DestinationText")
$OSText = $window.FindName("OSText")
$FriendText = $window.FindName("FriendText")
$FriendDetails = $window.FindName("FriendDetails")
$EnterButton = $window.FindName("EnterButton")
$ArchiveCheck = $window.FindName("ArchiveCheck")
$CuratedCheck = $window.FindName("CuratedCheck")
$AIcheck = $window.FindName("AIcheck")

foreach($y in $config.supported_years) { [void]$YearBox.Items.Add([string]$y) }
$YearBox.SelectedItem = [string]$config.default.year

foreach($o in $config.os_destinations) { [void]$OSBox.Items.Add([string]$o.name) }
$OSBox.SelectedItem = [string]$config.default.os

foreach($p in $friendData.PSObject.Properties.Name) { [void]$FriendBox.Items.Add($p) }
$FriendBox.SelectedItem = [string]$config.default.friend_pack

$DateBox.SelectedDate = Get-Date ("{0}-{1:D2}-{2:D2}" -f $config.default.year,$config.default.month,$config.default.day)
$TimeBox.Text = $config.default.time

function Update-Preview {
    $year = [int]$YearBox.SelectedItem
    $d = $DateBox.SelectedDate
    if($null -eq $d) { $d = Get-Date "$year-01-01" }
    if($d.Year -ne $year) {
        try { $DateBox.SelectedDate = Get-Date ("{0}-{1:D2}-{2:D2}" -f $year,$d.Month,[Math]::Min($d.Day,28)) }
        catch { $DateBox.SelectedDate = Get-Date "$year-01-01" }
        $d = $DateBox.SelectedDate
    }

    try {
        $time = [DateTime]::ParseExact($TimeBox.Text,"HH:mm",$null)
        $displayTime = $time.ToString("h:mm tt")
    } catch {
        $displayTime = $TimeBox.Text
    }

    $DestinationText.Text = ($d.ToString("MMMM d, yyyy").ToUpper() + " • " + $displayTime)
    $OSText.Text = [string]$OSBox.SelectedItem
    $FriendText.Text = [string]$FriendBox.SelectedItem

    $packName = [string]$FriendBox.SelectedItem
    $members = @()
    if($friendData.PSObject.Properties.Name -contains $packName) {
        $members = @($friendData.$packName | ForEach-Object { $_.name })
    }
    $FriendDetails.Text = ($members -join " • ")
}

$YearBox.Add_SelectionChanged({ Update-Preview })
$OSBox.Add_SelectionChanged({ Update-Preview })
$FriendBox.Add_SelectionChanged({ Update-Preview })
$DateBox.Add_SelectedDateChanged({ Update-Preview })
$TimeBox.Add_TextChanged({ Update-Preview })

$EnterButton.Add_Click({
    $session = [ordered]@{
        created_at = (Get-Date).ToString("o")
        year = [int]$YearBox.SelectedItem
        date = $DateBox.SelectedDate.ToString("yyyy-MM-dd")
        time = $TimeBox.Text
        os = [string]$OSBox.SelectedItem
        friend_pack = [string]$FriendBox.SelectedItem
        network = [ordered]@{
            mode = "TimeNet"
            archived_web = [bool]$ArchiveCheck.IsChecked
            curated_fallback = [bool]$CuratedCheck.IsChecked
            ai_contacts = [bool]$AIcheck.IsChecked
        }
        prototype_action = "prepared"
        vm_image = $null
        note = "Prototype 2 prepares the control-plane configuration. VM launch is intentionally not wired until a VM engine and user-supplied OS environment are configured."
    }

    $session | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $StatePath -Encoding UTF8
    Write-Log ("Prepared timeline: " + ($session | ConvertTo-Json -Compress))

    [System.Windows.MessageBox]::Show(
        "Timeline prepared.`n`n$($session.date) at $($session.time)`n$($session.os)`n$($session.friend_pack)`n`nPrototype 2 stops here intentionally. The next build will connect this session to the isolated Windows VM and TimeNet.",
        "Frozen in Time",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    ) | Out-Null
})

Update-Preview
Write-Log "Prototype 2 launcher opened."
[void]$window.ShowDialog()


$Base = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Write-Host ""
Write-Host "FROZEN IN TIME - PROTOTYPE 2 STATUS" -ForegroundColor Cyan
Write-Host "===================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Launcher:" -NoNewline; Write-Host " READY" -ForegroundColor Green
Write-Host "TimeNet architecture stub:" -NoNewline; Write-Host " READY" -ForegroundColor Green
Write-Host "Friend/persona data:" -NoNewline; Write-Host " READY" -ForegroundColor Green
Write-Host "Windows 7 VM:" -NoNewline; Write-Host " NOT CONNECTED" -ForegroundColor Yellow
Write-Host "Bootable ISO layer:" -NoNewline; Write-Host " NOT BUILT YET" -ForegroundColor Yellow
Write-Host ""
Write-Host "This prototype is the control-plane/launcher step before the bootable ISO." -ForegroundColor Gray
Write-Host "No Windows ISO is included or downloaded by this package." -ForegroundColor Gray
Write-Host ""
Read-Host "Press Enter to close"

# Frozen in Time OS

**Pick a year. Enter a living digital past.**

Frozen in Time OS is a prototype for a portable digital time machine.

The long-term idea is to let a user select a year, date, operating-system environment, and AI friend group, then enter a time-locked digital world where websites, software, news, culture, downloads, and AI contacts behave as if they exist in that period.

## Current Prototype

Prototype 2 (`v0.2`) is focused on the launcher/control layer.

It currently provides:

- Native Windows launcher
- Year selection
- Date and time selection
- OS destination selection
- AI friend-pack selection
- TimeNet configuration options
- Timeline session generation
- Project structure for future VM and server integration

The current prototype **does not yet launch a Windows virtual machine**.

## Vision

The intended architecture is:

```text
Computer boots from Frozen in Time USB
        |
        v
Frozen in Time launcher
        |
        v
Choose year / date / OS / friends
        |
        v
Isolated period Windows virtual machine
        |
        v
Frozen TimeNet network layer
        |
        +--> historical / archived websites
        +--> era-accurate search
        +--> historical news and trends
        +--> curated retro downloads
        +--> AI contacts locked to the selected timeline
```

## Frozen Timeline Mode

Changing the selected date is intended to change the entire simulated digital world:

- websites
- news
- search results
- advertisements
- game releases
- tech releases
- cultural references
- AI conversations
- social-network content

AI contacts are designed to obey the selected timeline's knowledge cutoff and avoid knowingly referencing future events.

## TimeNet

TimeNet is the planned network layer for Frozen in Time OS.

Its future responsibilities include:

- archived-page resolution
- historical search
- historical news/weather/trends
- era-appropriate advertisements
- curated retro downloads
- AI contact routing
- isolation between old software and the modern host computer

Archived files will not automatically execute on the user's host operating system.

## Windows and Other Operating Systems

Frozen in Time OS itself does **not** include Microsoft Windows installation media or product keys.

The planned architecture supports isolated virtual machines created using appropriately licensed or user-supplied operating-system media.

Frozen in Time is intended to control the **timeline around the operating system**, rather than modifying the host computer's Windows installation.

## Repository Structure

```text
launcher/   Native Frozen in Time launcher prototype
config/     Era definitions and saved session configuration
friends/    AI persona definitions
timenet/    Future TimeNet architecture
vm/         Future virtual-machine integration point
logs/       Runtime logs
docs/       Architecture notes
```

## Running Prototype 2

On Windows:

1. Download or clone this repository.
2. Open the project folder.
3. Run:

```text
START_FROZEN_IN_TIME.cmd
```

4. Choose a year, date, time, OS destination, and friend pack.
5. Click **PREPARE TIMELINE**.

The resulting session configuration is written to:

```text
config/last-session.json
```

## Roadmap

- [x] Native launcher prototype
- [x] Timeline configuration
- [x] Friend/persona data model
- [x] TimeNet architecture stub
- [ ] Bootable USB / ISO host environment
- [ ] Virtual-machine launcher
- [ ] Windows 7 proof-of-concept VM
- [ ] TimeNet proxy/router
- [ ] Historical web archive integration
- [ ] AI contact service
- [ ] Persistent AI memories
- [ ] Curated download resolver
- [ ] Additional years and operating systems
- [ ] Collector USB edition

## Important

This repository is an early prototype and concept implementation.

It does not modify Windows system files, install an operating system, include proprietary Windows images, or provide copyrighted commercial software.

---

**Frozen in Time OS**  
*The Internet Lives On.*
